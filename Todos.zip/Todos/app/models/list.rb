class List < ActiveRecord::Base
end

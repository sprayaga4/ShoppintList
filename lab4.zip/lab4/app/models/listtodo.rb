class Listtodo < ActiveRecord::Base
end

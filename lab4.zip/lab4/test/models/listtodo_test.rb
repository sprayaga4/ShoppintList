require 'test_helper'

class ListtodoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
